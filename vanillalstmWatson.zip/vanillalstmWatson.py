# @hidden_cell
# The following code contains the credentials for a file in your IBM Cloud Object Storage.
# You might want to remove those credentials before you share your notebook.
credentials_1 = {
'IAM_SERVICE_ID': 'iam-ServiceId-f69ab471-4081-42eb-9358-4ea59a021f1f',
'IBM_API_KEY_ID': 'fKT8EoY0IAJ-3hjVjZVrecjICAWGoLBHoM-bkCXaV93g',
'ENDPOINT': 'https://s3-api.us-geo.objectstorage.service.networklayer.com',
'IBM_AUTH_ENDPOINT': 'https://iam.ng.bluemix.net/oidc/token',
'BUCKET': 'notebooklstm-donotdelete-pr-8vgfmcnsqfc7eb',
'FILE': 'df_Earth_Temp.csv'
}

from ibm_botocore.client import Config
import ibm_boto3

cos = ibm_boto3.client(service_name='s3',
ibm_api_key_id=credentials_1['IBM_API_KEY_ID'],
ibm_service_instance_id=credentials_1['IAM_SERVICE_ID'],
ibm_auth_endpoint=credentials_1['IBM_AUTH_ENDPOINT'],
config=Config(signature_version='oauth'),
endpoint_url=credentials_1['ENDPOINT'])

cos.download_file(Bucket=credentials_1['BUCKET'],Key='df_Earth_Temp.csv',Filename='df_Earth_Temp.csv')

# Importando o frame de um 1.002.019 anos
df_Temperatura = pd.DataFrame(pd.read_csv('df_Earth_Temp.csv'))
#Colocando o ano como índice para visualizar melhor no gráfico
df_Temperatura.set_index('ano', inplace=True)
# Criando a LISTA que será usada de fato
df_serie = df_Temperatura[df_Temperatura.index < 2000]
df_serie.reset_index(drop=True, inplace=True)
serie = df_serie.Earth_avg_temp.values.tolist()

# Função para dividir a sequencia univariável em amostras
from numpy import array
def split_sequence(sequence, n_steps):
X, y = list(), list()
for i in range(len(sequence)):
    # find the end of this pattern
    end_ix = i + n_steps
    # check if we are beyond the sequence
    if end_ix > len(sequence)-1:
        break
    # gather input and output parts of the pattern
    seq_x, seq_y = sequence[i:end_ix], sequence[end_ix]
    X.append(seq_x)
    y.append(seq_y)
return array(X), array(y)

# Utilizar 500 mil anos
serie = serie[-500000:]

# Definindo o tamanho das amostras
n = 200
# Aplicando a separação em x e y
%time x, y = split_sequence(serie, n)

# reformatando de [samples, timesteps] para [samples, timesteps, features]
x = x.reshape((x.shape[0], x.shape[1], 1))

from keras.models import Sequential
from keras.layers import LSTM
from keras.layers import Dense
from keras.utils.vis_utils import plot_model
from keras.optimizers import Adam
from IPython.display import Image
#from keras.layers import LeakyReLU
from keras.callbacks import EarlyStopping

# Parâmetros
neurons = 50
lr = 0.001
batch_size = 500

# Modelo
model = Sequential()

model.add(LSTM(neurons, activation='relu', input_shape=(n, 1)))
model.add(Dense(1))

model.compile(optimizer=Adam(lr=lr), loss='mse')

# Treinando o modelo
history = model.fit(x, y, epochs=200, verbose=1, callbacks=[monitor], batch_size=batch_size)

print(f'Loss: {history.history['loss']}')
